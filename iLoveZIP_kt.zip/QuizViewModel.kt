package com.example.geoquiz

import androidx.lifecycle.ViewModel
import com.example.geoquiz.data.Question
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class QuizViewModel : ViewModel() {

    private val questionBank = listOf(
        Question(R.string.question_solar_system, true),
        Question(R.string.question_louvre_location, true),
        Question(R.string.question_great_wall_visibility, false),
        Question(R.string.question_h2o_formula, true),
        Question(R.string.question_fastest_land_animal, true),
        Question(R.string.question_vangogh_ear, false),
        Question(R.string.question_olympics_origin, true),
        Question(R.string.question_largest_ocean, true),
        Question(R.string.question_oxygen_percentage, false),
        Question(R.string.question_roman_empire_fall, false)
    )

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex

    private val _feedback = MutableStateFlow<String?>(null)
    val feedback: StateFlow<String?> = _feedback

    private val _correctAnswers = MutableStateFlow(0)
    val correctAnswers: StateFlow<Int> = _correctAnswers

    // Devuelve la pregunta actual según el índice
    fun getQuestionAt(index: Int): Question {
        return questionBank[index]
    }

    // Contestar pregunta
    fun answerQuestion(userAnswer: Boolean) {
        val currentQuestion = getQuestionAt(_currentIndex.value)
        if (userAnswer == currentQuestion.answer) {
            _feedback.value = "Correct!"
            _correctAnswers.value += 1
        } else {
            _feedback.value = "Incorrect!"
        }
    }

    // Navegar a la siguiente pregunta (libre, sin restricciones)
    fun nextQuestion() {
        _currentIndex.value = (_currentIndex.value + 1) % questionBank.size
        _feedback.value = null
    }

    // Navegar a la pregunta anterior (libre, sin restricciones)
    fun previousQuestion() {
        _currentIndex.value =
            if (_currentIndex.value - 1 < 0) questionBank.size - 1 else _currentIndex.value - 1
        _feedback.value = null
    }
}
