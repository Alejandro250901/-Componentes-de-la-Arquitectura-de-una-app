package com.example.geoquiz

import org.junit.Assert.assertEquals
import org.junit.Test

class QuizViewModelTest {

    @Test
    fun testCorrectAnswersCount() {
        val viewModel = QuizViewModel()

        // Contestar correctamente la primera pregunta
        val firstQuestion = viewModel.getQuestionAt(0)
        viewModel.answerQuestion(firstQuestion.answer)
        assertEquals(1, viewModel.correctAnswers.value)

        // Contestar incorrectamente la segunda pregunta
        viewModel.nextQuestion()
        val secondQuestion = viewModel.getQuestionAt(1)
        viewModel.answerQuestion(!secondQuestion.answer)
        assertEquals(1, viewModel.correctAnswers.value) // no debe aumentar
    }
}