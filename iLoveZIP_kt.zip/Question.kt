package com.example.geoquiz.data

data class Question(
    val textResId: Int,
    val answer: Boolean
)
